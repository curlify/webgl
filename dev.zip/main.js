var cmsscript = {}

cmsscript.new = function() {
  var instance = rectangle.new(screenWidth,screenHeight,{red:1,green:1,blue:1})
  
  var pc1 = image.new("ad2-2.png")
  var pc2 = image.new("ad2-3.png")
  
  var pieces = []
  pieces.push( pc1 )
  pieces.push( pc2 )
  
  var cols = 5
  var rows = 8
  var itemsizex = 70
  var itemsizey = 65
  
  var gamearea = instance.add( object.new() )
  gamearea.position.y = -30
  gamearea.size.width = cols*itemsizex
  gamearea.size.height = rows*itemsizey
  
  pc2.onload = function(){
  for (var y=0;y<rows;y++) {
    for (var x=0;x<cols;x++) {
      new function() {
      var rnd = getRandom(0,pieces.length)
      var piece = gamearea.add( button.new( pieces[rnd] ) )
      piece.position.x = -gamearea.size.width/2+itemsizex/2+x*itemsizex
      piece.position.y = -gamearea.size.height/2+itemsizey/2+y*itemsizey
      piece.originalposition = {x:piece.position.x,y:piece.position.y}
      piece.scale.x = 0
      piece.scale.y = 0
      piece.anim.animate( piece.scale, {x:1,y:1,start:Math.random()*2000,time:500,ease:animator.outQuad})
      //console.log("piece pos",piece.position.x,piece.position.y)
      piece.focus = function(x,y) {
        piece.offset = {x:x,y:y}
        //console.log("offset",x,y)
        scene.stealPointers(piece)
      }
      piece.hit = function(x,y) {
        if (piece.focused) return true
        if (x < -this.width()/2 || x > this.width()/2 || y < -this.height()/2 || y > this.height()/2) return false
        return true
      }
      piece.defocus = function(x,y) {
        piece.anim.animate( piece.position, {x:piece.originalposition.x,y:piece.originalposition.y,time:250,ease:animator.outQuad} )
      }
      piece.absoluteDrag = function(x,y) {
        if (this.focused == false) return
        x = x-screenWidth/2
        y = y-screenHeight/2
        //console.log("drag",x,y)
        piece.position.x = x-piece.offset.x
        piece.position.y = y-piece.offset.y-gamearea.position.y
        
        for (var i=0;i<gamearea.children.length;i++) {
          new function() {
            var child = gamearea.children[i]
            if (child != piece && child.anim.animations.length == 0) {
              var distx = Math.abs(piece.position.x-child.position.x)
              var disty = Math.abs(piece.position.y-child.position.y)
              if (distx <= itemsizex/2 && disty <= itemsizey/2) {
                child.anim.animate( child.position, {x:piece.originalposition.x,y:piece.originalposition.y,time:250,ease:animator.outQuad} )
                var op = child.originalposition
                child.originalposition = piece.originalposition
                piece.originalposition = op
              }
            }
          }
        }
        
      }
      }
    }
  }
  }
  
  var logo = instance.add( image.new("ad2-1.png") )
  logo.onload = function() {
    logo.position.y = viewHeight/2-logo.height()/2
  }
  
  return instance
}