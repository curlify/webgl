
var app = function() {

  var instance = object.new("preview application")

  JSZipUtils.getBinaryContent("dev.zip", function(err, data) {

    if(err) {
      console.log("ERROR: unable to load zip",err)
      return
    }

    zip = new JSZip(data);
    console.log("zip loaded : ",zip.files)

    var adscriptfile = zip.file("main.js")
    console.log(adscriptfile)

    if (adscriptfile == null) {
      console.log("ERROR: no main.js found in zip")
      zip = null
      return
    }
    
    var adobject = ziprequire(adscriptfile)
    zip = null
    console.log( adobject )

    instance.add( adobject )
  })

  return instance
}

app.new = function() {
  return new app()
}
